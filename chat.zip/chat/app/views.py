from django.shortcuts import render

def room(request, room_name):
    # Your view logic here
    return render(request, 'room.html', {'room_name': room_name})
