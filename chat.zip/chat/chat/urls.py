from django.contrib import admin
from django.urls import path, re_path
from app.views import room
from app.consumers import TextRoomConsumer
from channels.routing import ProtocolTypeRouter, URLRouter
from django.core.asgi import get_asgi_application

websocket_urlpatterns = [
    re_path(r'^ws/(?P<room_name>[^/]+)/$', TextRoomConsumer.as_asgi()),
]

application = ProtocolTypeRouter({
    'http': get_asgi_application(),
    'websocket': URLRouter(websocket_urlpatterns),
})

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^(?P<room_name>[^/]+)/$', room, name='room'),
]
